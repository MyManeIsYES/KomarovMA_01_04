﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KomarovMA_01_04
{
    internal class Program
    {

        static void Main(string[] args)
        {
            //Ввод данных базового класса
            Console.WriteLine("Введите наименование процессора Базового класса: ");
            string NameProcess = Console.ReadLine();

            Console.WriteLine("Введите тактовая частота процессора (МГц) Базового класса: ");
            double taktovai_zastota_process = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите объем оперативной памяти (Мб) Базового класса: ");
            double obiem_operativnoi_pamiti = Convert.ToDouble(Console.ReadLine());

            //Создание обьекта базового класса
            Compiuter pc = new Compiuter(NameProcess, taktovai_zastota_process, obiem_operativnoi_pamiti);

            //Вывод информации и качество базового класса
            Console.WriteLine("\nИнформация Базового класса:\n" + pc.Info());
            Console.WriteLine("\nКачество Базового класса:\n" + pc.Q());


            //Ввод данных класса потомока
            Console.WriteLine("\nВведите наименование процессора класса потомка: ");
            NameProcess = Console.ReadLine();

            Console.WriteLine("Введите тактовая частота процессора (МГц) класса потомка: ");
            taktovai_zastota_process = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите объем оперативной памяти (Мб) класса потомка: ");
            obiem_operativnoi_pamiti = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Введите объём винчестера (Гб) класса потомка: ");
            uint obiem_vinchestera = Convert.ToUInt32(Console.ReadLine());

            //Создание обьекта класса потомока
            class1 c1 = new class1(NameProcess, taktovai_zastota_process, obiem_operativnoi_pamiti, obiem_vinchestera);

            //Вывод информации и качество класса потомока
            Console.WriteLine("\nИнформация класса потомка:\n" + c1.Info());
            Console.WriteLine("\nКачество  класса потомка:\n" + c1.Qp());




        }
    }
}
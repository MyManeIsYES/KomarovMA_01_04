﻿namespace KomarovMA_01_04
{
    //Базовый класс комьпьютер
    class Compiuter
{
    //наименование процессора
    string NameProcess;
    //тактовая частота процессора (МГц)
    double taktovai_zastota_process;
    //объем оперативной памяти(Мб)
    double obiem_operativnoi_pamiti;


    public Compiuter(string nameProcess, double taktovai_zastota_process, double obiem_operativnoi_pamiti)
    {
        this.NameProcess = nameProcess;
        this.taktovai_zastota_process = taktovai_zastota_process;
        this.obiem_operativnoi_pamiti = obiem_operativnoi_pamiti;
    }

    //Качество базового класса
    public double Q()
    {
        return (0.3 * taktovai_zastota_process) + obiem_operativnoi_pamiti;
    }

    //Информация
    public string Info()
    {
        return (
            "Наименование процессора: " + NameProcess +
            "\nТактовая частота процессора: " + taktovai_zastota_process +
            "\nОбъем оперативной памяти: " + obiem_operativnoi_pamiti);
    }
}
//Класс потомок класса компьютер
class class1 : Compiuter
{
    //объём винчестера (Гб)
    uint obiem_vinchestera;

    public class1(string nameProcess, double taktovai_zastota_process, double obiem_operativnoi_pamiti, uint obiem_vinchestera) : base(nameProcess, taktovai_zastota_process, obiem_operativnoi_pamiti)
    {
        this.obiem_vinchestera = obiem_vinchestera;
    }
    //Качество класса потомок
    public double Qp()
    {
        double Qp;
        if (obiem_vinchestera > 500)
        {
            Qp = this.Q() + 0.5 * (double)obiem_vinchestera;
        }
        else
        {
            Qp = this.Q() + 1.5 * (double)obiem_vinchestera;
        }
        return Qp;
    }
}
}